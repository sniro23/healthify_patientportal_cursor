"use client"

import { Toaster } from "@/components/ui/toaster"
import { Toaster as Sonner } from "@/components/ui/sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom"
import { useEffect, useState } from "react"
import NotFound from "./pages/NotFound"
import SplashScreen from "./pages/SplashScreen"
import Login from "./pages/Login"
import Register from "./pages/Register"
import ForgotPassword from "./pages/ForgotPassword"
import ProfileSetup from "./pages/ProfileSetup"
import Dashboard from "./pages/Dashboard"
import Profile from "./pages/Profile"
import HealthRecord from "./pages/HealthRecord"
import { supabase } from "./lib/supabase"

// Appointment pages
import BookAppointment from "./pages/appointments/BookAppointment"
import UrgentConsultation from "./pages/appointments/UrgentConsultation"
import ScheduledConsultation from "./pages/appointments/ScheduledConsultation"
import HomeVisit from "./pages/appointments/HomeVisit"
import Payment from "./pages/appointments/Payment"
import Confirmation from "./pages/appointments/Confirmation"
import AppointmentHistory from "./pages/appointments/AppointmentHistory"
import AppointmentDetails from "./pages/appointments/AppointmentDetails"

// Chat/Consultation pages
import ChatOverviewPage from "./pages/chat/ChatOverviewPage"
import NewChatPage from "./pages/chat/NewChatPage"
import WaitingForDoctorPage from "./pages/chat/WaitingForDoctorPage"
import ChatSessionPage from "./pages/chat/ChatSessionPage"
import ChatEndedPage from "./pages/chat/ChatEndedPage"
import VisitSummaryPage from "./pages/consultations/VisitSummaryPage"

// Medication pages
import MedicationSummary from "./pages/medications/MedicationSummary"
import AddMedication from "./pages/medications/AddMedication"
import PrescriptionDetails from "./pages/medications/PrescriptionDetails"

const queryClient = new QueryClient()

// Auth guard component to protect routes
const RequireAuth = ({ children }: { children: JSX.Element }) => {
  const navigate = useNavigate()
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [hasCompletedProfile, setHasCompletedProfile] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if user is authenticated with Supabase
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          navigate("/login")
          return
        }

        setIsAuthenticated(true)

        // Check if user has completed profile
        const { data: userProfile, error } = await supabase
          .from("users")
          .select("id")
          .eq("id", session.user.id)
          .single()

        if (error && error.code !== "PGRST116") {
          console.error("Error checking profile:", error)
        }

        if (userProfile) {
          setHasCompletedProfile(true)
        } else {
          navigate("/profile-setup")
          return
        }
      } catch (error) {
        console.error("Auth check error:", error)
        navigate("/login")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [navigate])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="animate-pulse-glow text-health-primary">Loading...</div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  if (!hasCompletedProfile) {
    return null
  }

  return children
}

// Check if first-time user
const CheckFirstTime = () => {
  const [redirectTo, setRedirectTo] = useState<string | null>(null)

  useEffect(() => {
    const checkFirstTime = async () => {
      const hasSeenSplash = localStorage.getItem("hasSeenSplash") === "true"

      if (!hasSeenSplash) {
        setRedirectTo("/splash")
        return
      }

      // Check if user is authenticated with Supabase
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        setRedirectTo("/login")
        return
      }

      setRedirectTo("/dashboard")
    }

    checkFirstTime()
  }, [])

  if (!redirectTo) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="animate-pulse-glow text-health-primary">Loading...</div>
      </div>
    )
  }

  return <Navigate to={redirectTo} />
}

const App = () => {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }, [])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="animate-pulse-glow text-health-primary">Loading...</div>
      </div>
    )
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<CheckFirstTime />} />
            <Route path="/splash" element={<SplashScreen />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/profile-setup" element={<ProfileSetup />} />
            <Route
              path="/dashboard"
              element={
                <RequireAuth>
                  <Dashboard />
                </RequireAuth>
              }
            />
            <Route
              path="/profile"
              element={
                <RequireAuth>
                  <Profile />
                </RequireAuth>
              }
            />
            <Route
              path="/health-record"
              element={
                <RequireAuth>
                  <HealthRecord />
                </RequireAuth>
              }
            />

            {/* Appointment Routes */}
            <Route
              path="/appointments/book"
              element={
                <RequireAuth>
                  <BookAppointment />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/urgent"
              element={
                <RequireAuth>
                  <UrgentConsultation />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/scheduled"
              element={
                <RequireAuth>
                  <ScheduledConsultation />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/home-visit"
              element={
                <RequireAuth>
                  <HomeVisit />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/payment"
              element={
                <RequireAuth>
                  <Payment />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/confirmation"
              element={
                <RequireAuth>
                  <Confirmation />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments"
              element={
                <RequireAuth>
                  <AppointmentHistory />
                </RequireAuth>
              }
            />
            <Route
              path="/appointments/:id"
              element={
                <RequireAuth>
                  <AppointmentDetails />
                </RequireAuth>
              }
            />

            {/* Chat Routes */}
            <Route
              path="/chat"
              element={
                <RequireAuth>
                  <ChatOverviewPage />
                </RequireAuth>
              }
            />
            <Route
              path="/chat/new"
              element={
                <RequireAuth>
                  <NewChatPage />
                </RequireAuth>
              }
            />
            <Route
              path="/chat/waiting"
              element={
                <RequireAuth>
                  <WaitingForDoctorPage />
                </RequireAuth>
              }
            />
            <Route
              path="/chat/:chatId"
              element={
                <RequireAuth>
                  <ChatSessionPage />
                </RequireAuth>
              }
            />
            <Route
              path="/chat/:chatId/ended"
              element={
                <RequireAuth>
                  <ChatEndedPage />
                </RequireAuth>
              }
            />
            <Route
              path="/consultations/summary/:summaryId"
              element={
                <RequireAuth>
                  <VisitSummaryPage />
                </RequireAuth>
              }
            />

            {/* Medication Routes */}
            <Route
              path="/medications"
              element={
                <RequireAuth>
                  <MedicationSummary />
                </RequireAuth>
              }
            />
            <Route
              path="/medications/add"
              element={
                <RequireAuth>
                  <AddMedication />
                </RequireAuth>
              }
            />
            <Route
              path="/medications/prescription/:prescriptionId"
              element={
                <RequireAuth>
                  <PrescriptionDetails />
                </RequireAuth>
              }
            />

            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  )
}

export default App
