import { supabase } from "./supabase"
import { toast } from "@/components/ui/use-toast"

export const logout = async () => {
  try {
    const { error } = await supabase.auth.signOut()

    if (error) {
      throw error
    }

    // Clear any local storage items
    localStorage.removeItem("hasCompletedProfile")

    return { success: true }
  } catch (error: any) {
    toast({
      title: "Logout failed",
      description: error.message || "There was a problem signing out",
      variant: "destructive",
    })

    return { success: false, error }
  }
}
