export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          created_at: string
          updated_at: string
          full_name: string | null
          date_of_birth: string | null
          gender: string | null
          address: string | null
          marital_status: string | null
          children: number | null
          subscription_tier: string | null
        }
        Insert: {
          id?: string
          email: string
          created_at?: string
          updated_at?: string
          full_name?: string | null
          date_of_birth?: string | null
          gender?: string | null
          address?: string | null
          marital_status?: string | null
          children?: number | null
          subscription_tier?: string | null
        }
        Update: {
          id?: string
          email?: string
          created_at?: string
          updated_at?: string
          full_name?: string | null
          date_of_birth?: string | null
          gender?: string | null
          address?: string | null
          marital_status?: string | null
          children?: number | null
          subscription_tier?: string | null
        }
      }
      health_profiles: {
        Row: {
          id: string
          user_id: string
          height: number | null
          weight: number | null
          bmi: number | null
          blood_group: string | null
          activity_level: string | null
          smoking_status: string | null
          alcohol_consumption: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          height?: number | null
          weight?: number | null
          bmi?: number | null
          blood_group?: string | null
          activity_level?: string | null
          smoking_status?: string | null
          alcohol_consumption?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          height?: number | null
          weight?: number | null
          bmi?: number | null
          blood_group?: string | null
          activity_level?: string | null
          smoking_status?: string | null
          alcohol_consumption?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      medical_histories: {
        Row: {
          id: string
          user_id: string
          condition_name: string
          diagnosed_date: string | null
          status: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          condition_name: string
          diagnosed_date?: string | null
          status?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          condition_name?: string
          diagnosed_date?: string | null
          status?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      allergies: {
        Row: {
          id: string
          user_id: string
          allergy_name: string
          severity: string | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          allergy_name: string
          severity?: string | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          allergy_name?: string
          severity?: string | null
          notes?: string | null
          created_at?: string
        }
      }
      surgeries: {
        Row: {
          id: string
          user_id: string
          surgery_name: string
          surgery_date: string | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          surgery_name: string
          surgery_date?: string | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          surgery_name?: string
          surgery_date?: string | null
          notes?: string | null
          created_at?: string
        }
      }
      doctors: {
        Row: {
          id: string
          full_name: string
          specialty: string
          qualification: string | null
          years_experience: number | null
          profile_image_url: string | null
          availability_status: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          full_name: string
          specialty: string
          qualification?: string | null
          years_experience?: number | null
          profile_image_url?: string | null
          availability_status?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          specialty?: string
          qualification?: string | null
          years_experience?: number | null
          profile_image_url?: string | null
          availability_status?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      appointments: {
        Row: {
          id: string
          user_id: string
          doctor_id: string | null
          appointment_type: string
          status: string
          scheduled_date: string
          scheduled_time: string
          duration_minutes: number | null
          chief_complaint: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          doctor_id?: string | null
          appointment_type: string
          status: string
          scheduled_date: string
          scheduled_time: string
          duration_minutes?: number | null
          chief_complaint?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          doctor_id?: string | null
          appointment_type?: string
          status?: string
          scheduled_date?: string
          scheduled_time?: string
          duration_minutes?: number | null
          chief_complaint?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      medications: {
        Row: {
          id: string
          user_id: string
          drug_name: string
          dosage: string | null
          frequency: string | null
          start_date: string | null
          end_date: string | null
          is_prescription: boolean | null
          prescribed_by: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          drug_name: string
          dosage?: string | null
          frequency?: string | null
          start_date?: string | null
          end_date?: string | null
          is_prescription?: boolean | null
          prescribed_by?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          drug_name?: string
          dosage?: string | null
          frequency?: string | null
          start_date?: string | null
          end_date?: string | null
          is_prescription?: boolean | null
          prescribed_by?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      chat_sessions: {
        Row: {
          id: string
          user_id: string
          doctor_id: string | null
          status: string
          started_at: string
          ended_at: string | null
          chief_complaint: string | null
          summary: string | null
        }
        Insert: {
          id?: string
          user_id: string
          doctor_id?: string | null
          status: string
          started_at?: string
          ended_at?: string | null
          chief_complaint?: string | null
          summary?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          doctor_id?: string | null
          status?: string
          started_at?: string
          ended_at?: string | null
          chief_complaint?: string | null
          summary?: string | null
        }
      }
      chat_messages: {
        Row: {
          id: string
          session_id: string
          sender_type: string
          sender_id: string
          message_text: string
          attachment_url: string | null
          sent_at: string
          read_at: string | null
        }
        Insert: {
          id?: string
          session_id: string
          sender_type: string
          sender_id: string
          message_text: string
          attachment_url?: string | null
          sent_at?: string
          read_at?: string | null
        }
        Update: {
          id?: string
          session_id?: string
          sender_type?: string
          sender_id?: string
          message_text?: string
          attachment_url?: string | null
          sent_at?: string
          read_at?: string | null
        }
      }
      visit_summaries: {
        Row: {
          id: string
          appointment_id: string | null
          chat_session_id: string | null
          user_id: string
          doctor_id: string | null
          diagnosis: string | null
          treatment_plan: string | null
          follow_up_instructions: string | null
          created_at: string
        }
        Insert: {
          id?: string
          appointment_id?: string | null
          chat_session_id?: string | null
          user_id: string
          doctor_id?: string | null
          diagnosis?: string | null
          treatment_plan?: string | null
          follow_up_instructions?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          appointment_id?: string | null
          chat_session_id?: string | null
          user_id?: string
          doctor_id?: string | null
          diagnosis?: string | null
          treatment_plan?: string | null
          follow_up_instructions?: string | null
          created_at?: string
        }
      }
      lab_tests: {
        Row: {
          id: string
          user_id: string
          test_name: string
          test_date: string
          result: string | null
          result_unit: string | null
          reference_range: string | null
          is_abnormal: boolean | null
          notes: string | null
          document_url: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          test_name: string
          test_date: string
          result?: string | null
          result_unit?: string | null
          reference_range?: string | null
          is_abnormal?: boolean | null
          notes?: string | null
          document_url?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          test_name?: string
          test_date?: string
          result?: string | null
          result_unit?: string | null
          reference_range?: string | null
          is_abnormal?: boolean | null
          notes?: string | null
          document_url?: string | null
          created_at?: string
        }
      }
      vitals: {
        Row: {
          id: string
          user_id: string
          vital_type: string
          value: string
          unit: string | null
          measured_at: string
          notes: string | null
        }
        Insert: {
          id?: string
          user_id: string
          vital_type: string
          value: string
          unit?: string | null
          measured_at?: string
          notes?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          vital_type?: string
          value?: string
          unit?: string | null
          measured_at?: string
          notes?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
