import { createClient } from "@supabase/supabase-js"
import type { Database } from "./database.types"

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://tqtzujkwwmaqlmleeyti.supabase.co"
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxdHp1amt3d21hcWxtbGVleXRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ2MzEwMjQsImV4cCI6MjA2MDIwNzAyNH0.NdLzjFNAttT4kGDUWu71Klz4xaVTqoCoFTSnEUyFSxs"

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)

// Helper function to get the current user
export const getCurrentUser = async () => {
  const {
    data: { user },
  } = await supabase.auth.getUser()
  return user
}

// Helper function to get the current user's ID
export const getCurrentUserId = async () => {
  const user = await getCurrentUser()
  return user?.id
}
