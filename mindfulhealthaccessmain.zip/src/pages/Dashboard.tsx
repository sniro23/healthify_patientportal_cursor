"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import PageContainer from "@/components/layout/PageContainer"
import SubscriptionBadge from "@/components/dashboard/SubscriptionBadge"
import { Calendar, PlusCircle, Activity, Pill, FileText, MessageCircle } from "lucide-react"
import AppointmentCard from "@/components/dashboard/AppointmentCard"
import QuickAccessCard from "@/components/dashboard/QuickAccessCard"
import { Button } from "@/components/ui/button"
import { supabase, getCurrentUser } from "@/lib/supabase"

const Dashboard = () => {
  const [userData, setUserData] = useState({
    name: "",
    subscriptionTier: "Basic",
  })
  const [upcomingAppointment, setUpcomingAppointment] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const user = await getCurrentUser()

        if (!user) {
          navigate("/login")
          return
        }

        // Fetch user profile data
        const { data: userProfile, error: userError } = await supabase
          .from("users")
          .select("*")
          .eq("id", user.id)
          .single()

        if (userError) {
          console.error("Error fetching user profile:", userError)
          // If user profile doesn't exist, redirect to profile setup
          if (userError.code === "PGRST116") {
            navigate("/profile-setup")
            return
          }
        }

        if (userProfile) {
          setUserData({
            name: userProfile.full_name?.split(" ")[0] || "User",
            subscriptionTier: userProfile.subscription_tier || "Basic",
          })
        }

        // Fetch upcoming appointment
        const today = new Date().toISOString().split("T")[0]

        const { data: appointments, error: appointmentError } = await supabase
          .from("appointments")
          .select(`
            *,
            doctors:doctor_id (
              full_name,
              specialty
            )
          `)
          .eq("user_id", user.id)
          .eq("status", "scheduled")
          .gte("scheduled_date", today)
          .order("scheduled_date", { ascending: true })
          .order("scheduled_time", { ascending: true })
          .limit(1)

        if (appointmentError) {
          console.error("Error fetching appointments:", appointmentError)
        }

        if (appointments && appointments.length > 0) {
          const appointment = appointments[0]

          // Format date and time for display
          const date = new Date(appointment.scheduled_date)
          const formattedDate = date.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          })

          // Parse time (assuming it's in HH:MM:SS format)
          const timeParts = appointment.scheduled_time.split(":")
          const hours = Number.parseInt(timeParts[0])
          const minutes = Number.parseInt(timeParts[1])

          // Format time in 12-hour format
          const period = hours >= 12 ? "PM" : "AM"
          const formattedHours = hours % 12 || 12
          const formattedTime = `${formattedHours}:${minutes.toString().padStart(2, "0")} ${period}`

          setUpcomingAppointment({
            id: appointment.id,
            doctorName: appointment.doctors?.full_name || "Doctor",
            specialty: appointment.doctors?.specialty || "Specialist",
            date: formattedDate,
            time: formattedTime,
            type: appointment.appointment_type.toLowerCase().includes("video") ? "video" : "in-person",
            status: "upcoming",
          })
        }

        setLoading(false)
      } catch (error) {
        console.error("Error loading dashboard data:", error)
        setLoading(false)
      }
    }

    fetchData()
  }, [navigate])

  const handleNewAppointment = () => {
    navigate("/appointments/book")
  }

  return (
    <PageContainer title="Healthify" className="space-y-6">
      {/* Welcome section with subscription */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-semibold">Hello, {userData.name || "User"}!</h1>
          <p className="text-sm text-slate-600">Welcome to Healthify Patient Portal</p>
        </div>
        <SubscriptionBadge tier={userData.subscriptionTier} />
      </div>

      {/* Next appointment */}
      <section>
        <div className="flex justify-between items-center mb-3">
          <h2 className="font-medium">Upcoming Appointment</h2>
          <Button variant="ghost" size="sm" className="text-health-primary" onClick={handleNewAppointment}>
            <PlusCircle size={16} className="mr-1" />
            Book New
          </Button>
        </div>

        {loading ? (
          <div className="h-20 bg-slate-100 rounded-lg animate-pulse" />
        ) : upcomingAppointment ? (
          <AppointmentCard {...upcomingAppointment} />
        ) : (
          <div className="p-4 text-center border border-dashed border-slate-200 rounded-lg bg-slate-50">
            <p className="text-slate-600 mb-2">No upcoming appointments</p>
            <Button size="sm" onClick={handleNewAppointment} className="bg-health-primary hover:bg-health-accent">
              Book Appointment
            </Button>
          </div>
        )}
      </section>

      {/* Quick access cards */}
      <section>
        <h2 className="font-medium mb-3">Quick Access</h2>
        <div className="grid grid-cols-2 gap-4">
          <QuickAccessCard
            title="Appointment History"
            icon={Calendar}
            to="/appointments"
            color="bg-blue-50 text-blue-600"
          />
          <QuickAccessCard title="My Medications" icon={Pill} to="/medications" color="bg-green-50 text-green-600" />
        </div>
      </section>

      {/* Health features */}
      <section>
        <h2 className="font-medium mb-3">Health Features</h2>
        <div className="grid grid-cols-2 gap-4">
          <QuickAccessCard
            title="Health Records"
            description="View your medical data"
            icon={FileText}
            to="/health-record"
          />
          <QuickAccessCard
            title="Consult a Doctor"
            description="Start a chat consultation"
            icon={MessageCircle}
            to="/chat/new"
          />
          <QuickAccessCard
            title="Health Trends"
            description="Track your progress"
            icon={Activity}
            to="/health-record"
            color="bg-purple-50 text-purple-600"
          />
        </div>
      </section>
    </PageContainer>
  )
}

export default Dashboard
